import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Настройки SMTP сервера
smtp_server = 'mail.hosting.reg.ru'  # SMTP сервер вашего почтового домена
smtp_port = 587  # Порт SMTP сервера
smtp_username = 'oauth@avtoservisnalesnoj.ru'  # Пользователь вашего почтового ящика
smtp_password = '122412500al'  # Пароль от почтового ящика
def postTo(to_email="allekskutuzov@gmail.com"):
    # Адрес получателя to_email
    
    # Создание письма
    msg = MIMEMultipart()
    msg['From'] = smtp_username
    msg['To'] = to_email
    msg['Subject'] = 'Подтверждение почты'
    
    # Текст письма
    body = """
    <html>
    <head>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
            }
            .container {
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #ffffff;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .header {
                background-color: #007bff;
                color: #ffffff;
                text-align: center;
                padding: 10px;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }
            .content {
                padding: 20px;
            }
            .button {
                display: inline-block;
                background-color: #007bff;
                color: #ffffff;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
            }
            .button:hover {
                background-color: #0056b3;
            }
            .footer {
                background-color: #f8f9fa;
                padding: 10px;
                text-align: center;
                border-bottom-left-radius: 5px;
                border-bottom-right-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Подтверждение почты</h2>
            </div>
            <div class="content">
                <p>Здравствуйте, добро пожаловать на сайт автосервиса "На лесной" г.Арзамаса, ваша почта должна быть подтверждена для завершения регистрации.</p>
                <a href='https://avtoservisnalesnoj.ru/"""+ "login' " + """ class="button">Подтвердить эл. почту</a>
            </div>
            <div class="footer">
                <p>Если вы не указывали свою почту, проигнорируйте это сообщение.</p>
            </div>
        </div>
    </body>
    </html>
    """
    msg.attach(MIMEText(body, 'html'))
    
    # Создание SMTP объекта
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()  # Шифрование для безопасной передачи пароля
    
    # Аутентификация
    server.login(smtp_username, smtp_password)
    
    # Отправка письма
    server.send_message(msg)
    
    # Закрытие соединения
    server.quit()
postTo()
