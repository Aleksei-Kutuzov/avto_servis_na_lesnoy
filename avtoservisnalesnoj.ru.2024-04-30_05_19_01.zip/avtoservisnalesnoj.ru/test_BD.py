from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
import pymysql

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://u2526817:122412500al@localhost/u2526817_users'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class UnconfirmedUser(db.Model):
    __tablename__ = 'unconfirmed_users'
    id = db.Column(db.Text(), primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    login = db.Column(db.String(255), nullable=False)
    password = db.Column(db.Text(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    picture = db.Column(db.String(255), nullable=False)
    host_key = db.Column(db.Text(), nullable=False)

    def __repr__(self):
        return "<{}:{}>".format(self.id, self.name[:10])

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Text(), primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    login = db.Column(db.String(255), nullable=False)
    password = db.Column(db.Text(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    picture = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return "<{}:{}>".format(self.id, self.name[:10])

@app.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    output = []
    for user in users:
        user_data = {'id': user.id, 'name': user.name, 'login': user.login, 'email': user.email, 'picture': user.picture}
        output.append(user_data)
    return jsonify({'users': output})

if __name__ == '__main__':
    app.run(host="0.0.0.0",debug=True)
